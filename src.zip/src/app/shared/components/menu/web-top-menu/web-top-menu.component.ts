import { Component, OnInit  } from '@angular/core';
import { Router, ActivatedRoute, NavigationEnd } from '@angular/router';
import { Location } from '@angular/common';
import { filter } from 'rxjs/operators';

@Component({
  selector: 'app-web-top-menu',
  templateUrl: './web-top-menu.component.html',
  styleUrls: ['./web-top-menu.component.css']
})
export class WebTopMenuComponent implements OnInit {
  currentPath: string = "/home";
  constructor(
    private activatedRoute: ActivatedRoute,
    private router: Router,
    private location: Location,
  ) {
    router.events.pipe(
      filter(event => event instanceof NavigationEnd)
    ).subscribe((event:any) => {
      console.log(event.url);
      this.currentPath = event.url;
    });
  }

  ngOnInit(): void {
  }
}
