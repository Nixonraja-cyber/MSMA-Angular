import { ComponentFixture, TestBed } from '@angular/core/testing';

import { WebTopMenuComponent } from './web-top-menu.component';

describe('WebTopMenuComponent', () => {
  let component: WebTopMenuComponent;
  let fixture: ComponentFixture<WebTopMenuComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ WebTopMenuComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(WebTopMenuComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
