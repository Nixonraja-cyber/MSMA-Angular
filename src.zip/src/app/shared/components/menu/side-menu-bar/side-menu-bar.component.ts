import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute, NavigationEnd } from '@angular/router';
import { Location } from '@angular/common';
import { filter } from 'rxjs/operators';

@Component({
  selector: 'app-side-menu-bar',
  templateUrl: './side-menu-bar.component.html',
  styleUrls: ['./side-menu-bar.component.css']
})
export class SideMenuBarComponent implements OnInit {
  currentPath: string = "/admin/dashboard";
  constructor(
    private activatedRoute: ActivatedRoute,
    private router: Router,
    private location: Location,
  ) {
    router.events.pipe(
      filter(event => event instanceof NavigationEnd)
    ).subscribe((event:any) => {
      console.log(event.url);
      this.currentPath = event.url;
    });
  }

  ngOnInit(): void {
  }

}
