export class Common {
    public id: number = 0;
}
