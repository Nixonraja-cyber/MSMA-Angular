import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { Logger } from './core/log';
import { ToastrModule } from 'ngx-toastr';

import { CookieService } from 'ngx-cookie-service';
import { HttpClientModule } from '@angular/common/http';
import { ServiceProvider } from './core/service/service.provider';
import { ServiceConfig } from './core/service/service.url.config';

import { WebLayoutComponent } from './shared/components/layouts/web-layout/web-layout.component';
import { WebTopMenuComponent } from './shared/components/menu/web-top-menu/web-top-menu.component';
import { WebFooterComponent } from './shared/components/footer/web-footer/web-footer.component';

import { LoginLayoutComponent } from './shared/components/layouts/login-layout/login-layout.component';
import { AdminLayoutComponent } from './shared/components/layouts/admin-layout/admin-layout.component';
import { LoginFooterComponent } from './shared/components/footer/login-footer/login-footer.component';
import { AdminFooterComponent } from './shared/components/footer/admin-footer/admin-footer.component';
import { TopMenuBarComponent } from './shared/components/menu/top-menu-bar/top-menu-bar.component';
import { SideMenuBarComponent } from './shared/components/menu/side-menu-bar/side-menu-bar.component';

import { LoaderComponent } from './shared/components/loader/loader.component';
import { NotfoundComponent } from './shared/components/notfound/notfound.component';

import { HomeComponent } from './modules/web/home/home.component';
import { AboutComponent } from './modules/web/about/about.component';
import { RegisterComponent } from './modules/web/register/register.component';
import { ContactComponent } from './modules/web/contact/contact.component';

import { LoginComponent } from './modules/login/login.component';
import { DashboardComponent } from './modules/dashboard/dashboard.component';
import { TermsComponent } from './modules/web/terms/terms.component';
import { PrivacyComponent } from './modules/web/privacy/privacy.component';

@NgModule({
  declarations: [
    AppComponent,
    WebLayoutComponent,
    WebTopMenuComponent,
    WebFooterComponent,
    LoginLayoutComponent,
    AdminLayoutComponent,
    LoginFooterComponent,
    AdminFooterComponent,
    TopMenuBarComponent,
    SideMenuBarComponent,
    LoaderComponent,
    NotfoundComponent,
    HomeComponent,
    AboutComponent,
    RegisterComponent,
    LoginComponent,
    DashboardComponent,
    ContactComponent,
    TermsComponent,
    PrivacyComponent,
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule,
    ToastrModule.forRoot({
      timeOut: 3000,
      positionClass: 'toast-bottom-right',
      preventDuplicates: true,
      closeButton: true
    }),
  ],
  providers: [
    {provide: ServiceProvider},
    Logger,
    ServiceConfig,
    CookieService,
  ],
  schemas: [
    CUSTOM_ELEMENTS_SCHEMA
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
