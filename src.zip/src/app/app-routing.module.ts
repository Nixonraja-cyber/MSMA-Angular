import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { WebLayoutComponent } from './shared/components/layouts/web-layout/web-layout.component';
import { WebTopMenuComponent } from './shared/components/menu/web-top-menu/web-top-menu.component';
import { WebFooterComponent } from './shared/components/footer/web-footer/web-footer.component';

import { LoginLayoutComponent } from './shared/components/layouts/login-layout/login-layout.component';
import { AdminLayoutComponent } from './shared/components/layouts/admin-layout/admin-layout.component';
import { LoginFooterComponent } from './shared/components/footer/login-footer/login-footer.component';
import { AdminFooterComponent } from './shared/components/footer/admin-footer/admin-footer.component';
import { TopMenuBarComponent } from './shared/components/menu/top-menu-bar/top-menu-bar.component';
import { SideMenuBarComponent } from './shared/components/menu/side-menu-bar/side-menu-bar.component';

import { LoaderComponent } from './shared/components/loader/loader.component';
import { NotfoundComponent } from './shared/components/notfound/notfound.component';

import { HomeComponent } from './modules/web/home/home.component';
import { AboutComponent } from './modules/web/about/about.component';
import { RegisterComponent } from './modules/web/register/register.component';
import { ContactComponent } from './modules/web/contact/contact.component';

import { LoginComponent } from './modules/login/login.component';
import { DashboardComponent } from './modules/dashboard/dashboard.component';
import { TermsComponent } from './modules/web/terms/terms.component';
import { PrivacyComponent } from './modules/web/privacy/privacy.component';

const routes: Routes = [
    // App default redirect page
    {
      path: '',
      redirectTo: 'home',
      pathMatch: 'full',
    },

    // App set/default Layout: Web layout
    {
      path: '',
      component: WebLayoutComponent,
      children: [
        { path: 'home', component: HomeComponent},
      ]
    },
    {
      path: '',
      component: WebLayoutComponent,
      children: [
        { path: 'about', component: AboutComponent},
      ]
    },
    {
      path: '',
      component: WebLayoutComponent,
      children: [
        { path: 'contact', component: ContactComponent},
      ]
    },
    {
      path: '',
      component: WebLayoutComponent,
      children: [
        { path: 'register', component: RegisterComponent},
      ]
    },
    {
      path: '',
      component: WebLayoutComponent,
      children: [
        { path: 'terms', component: TermsComponent},
      ]
    },
    {
      path: '',
      component: WebLayoutComponent,
      children: [
        { path: 'privacy', component: PrivacyComponent},
      ]
    },

    {
      path: '',
      component: WebLayoutComponent,
      children: [
        { path: 'login', component: LoginComponent},
      ]
    },

    {
      path: '',
      component: WebLayoutComponent,
      children: [
        { path: 'dashboard', component: DashboardComponent},
      ]
    },

    // App page not found redirect
    {
      path: '**',
      component: NotfoundComponent
    },
  ];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
