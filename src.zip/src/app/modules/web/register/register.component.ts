import { Component } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { first, tap, filter } from 'rxjs/operators';
import { ToastrService } from 'ngx-toastr';

import { RegisterService } from '../../../core/service/register/register.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent {

  regForm:any = FormGroup;
  submitted = false;
  submitbtnDisable = true;

  fname = "";
  lname = "";
  dob = "";
  medicalcollege = "";
  yearofjoining = "";
  qualifications = "";
  speciality = "";
  inpracticeretired = "";
  singlemarried = "";
  associations = "";
  children = "";
  address = "";
  phonenumber = "";
  emailid = "";
  password = "";
  confirmpassword = "";
  termscondition = false;

  constructor(
    private formBuilder: FormBuilder,
    private route: ActivatedRoute,
    private router: Router,
    private toastr: ToastrService,
    private registerService: RegisterService,
  ) { }

  // convenience getter for easy access to form fields
  get f() { return this.regForm.controls; }

  ngOnInit(): void {
    this.regForm = this.formBuilder.group({
      fname: [this.fname, Validators.required],
      lname: [this.lname, Validators.required],
      dob: [this.dob, Validators.required],
      medicalcollege: [this.medicalcollege, Validators.required],
      yearofjoining: [this.yearofjoining, Validators.required],
      qualifications: [this.qualifications, Validators.required],
      speciality: [this.speciality, Validators.required],
      inpracticeretired: [this.inpracticeretired, Validators.required],
      singlemarried: [this.singlemarried, Validators.required],
      associations: [this.associations],
      children: [this.children],
      address: [this.address],
      phonenumber: [this.phonenumber, Validators.required],
      emailid: [this.emailid, Validators.required, Validators.email],
      password: [this.password, Validators.required],
      confirmpassword: [this.confirmpassword, Validators.required],
      termscondition: [this.termscondition, Validators.required],
    });
  }

  regSubmit() {
    this.submitted = true;
    this.submitbtnDisable = true;

    // stop here if form is invalid
    if (this.regForm.invalid) {
      this.submitbtnDisable = false;
      this.toastr.error('Enter the mandatory fields!', 'Failed');
      return;
    };
    const bodyQuery = {
      "fname": this.f.fname.value,
      "lname": this.f.lname.value,
      "dob": this.f.dob.value,
      "medicalcollege": this.f.medicalcollege.value,
      "yearofjoining": this.f.yearofjoining.value,
      "qualifications": this.f.qualifications.value,
      "speciality": this.f.speciality.value,
      "inpracticeretired": this.f.inpracticeretired.value,
      "associations": this.f.associations.value,
      "singlemarried": this.f.singlemarried.value,
      "address": this.f.address.value,
      "children": this.f.children.value,
      "emailid": this.f.emailid.value,
      "password": this.f.password.value,
      "confirmPassword": this.f.confirmpassword.value,
      "phone": this.f.phonenumber.value
   }
   this.registerService.doctorRegistration(bodyQuery).subscribe({
    next: (data: any) =>{
      if (data.body.code === '200') {
        this.toastr.success('Registered successfully', 'Success');
      } else {
        this.toastr.error('Unable to submit your registration!', 'Failed');
      }
      this.submitted = false;
      this.submitbtnDisable = false;
    },
    error: (err: any) => {
      this.toastr.error(err.error.message, 'Failed');
      this.submitbtnDisable = false;
      this.submitted = false;
    }
   })

    // this.registerService.doctorRegistration(bodyQuery)
    // .pipe(first())
    // .subscribe(
    //   data => {
    //     if (data.body.code === '200') {
    //       this.toastr.success('Registered successfully', 'Success');
    //     } else {
    //       this.toastr.error('Unable to submit your registration!', 'Failed');
    //     }
    //     this.submitted = false;
    //     this.submitbtnDisable = false;
    //   },
    //   error => {
    //     this.toastr.error(error.error.message, 'Failed');
    //     this.submitbtnDisable = false;
    //     this.submitted = false;
    //   });
  }
  enableSubmitBtn(){
    if (!this.f.termscondition.value){
      this.submitbtnDisable = false;
    } else {
      this.submitbtnDisable = true;
    }
  }

}
