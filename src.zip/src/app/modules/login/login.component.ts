import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent {
  username!: string;
  password!: string;
  errorMessage!: string;
  returnUrl!: string;

  constructor(private router: Router) { }

  onSubmit() {
    // Handle form submission logic here
  
    // Navigate to the dashboard after successful submission

    if (this.username === 'testuser' && this.password === 'admin') {
      this.router.navigate(['/dashboard']);
      // You can redirect the user to another page or perform any other action here
      console.log('Login successful!');
    } else {
      // Invalid credentials
      this.errorMessage = 'Invalid username or password.';
    }
    
  }

}


/*

  */