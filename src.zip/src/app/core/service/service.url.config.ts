import { environment } from '../../../environments/environment';

export class ServiceConfig {
  public static API_ENDPOINT = environment.baseUrl;

  public services = {
    // Login API's
    login: { url: ServiceConfig.API_ENDPOINT + 'login', header: true, autherization: false },
    logout: { url: ServiceConfig.API_ENDPOINT + 'logout', header: true, autherization: true },

    registration: { url: ServiceConfig.API_ENDPOINT + 'register/doctor', header: true, autherization: false },

  };
}
