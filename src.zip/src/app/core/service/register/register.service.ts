import { Injectable } from '@angular/core';
import { ServiceProvider } from '../service.provider';
import { map } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class RegisterService {

  constructor(private dataService: ServiceProvider) { }

  public doctorRegistration(bodyParams: any) {
    return this.dataService.post('registration', bodyParams)
      .pipe(map(data => {
        return data;
      }
      ));
  }
}
