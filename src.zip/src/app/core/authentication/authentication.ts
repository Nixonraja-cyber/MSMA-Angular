import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';
import { ServiceProvider } from '../service/service.provider';
import { map } from 'rxjs/operators';

import { User } from '../../shared/models/user.model';

@Injectable({ providedIn: 'root' })
export class AuthenticationService {
    private currentUserSubject: BehaviorSubject<User>;
    public currentUser: Observable<User>;

    constructor(public dataService: ServiceProvider) {
        this.currentUserSubject = new BehaviorSubject<User>(JSON.parse(localStorage.getItem('currentUser')));
        this.currentUser = this.currentUserSubject.asObservable();
    }

    public get currentUserValue(): User {
        return this.currentUserSubject.value;
    }

    login(userName: any, userPassword: any) {
        const requestQuery = {
            username: userName,
            password: userPassword
          };
        return this.dataService.post('login', requestQuery)
            .pipe(map(user => {
                // store user details and jwt token in local storage to keep user logged in between page refreshes
                localStorage.setItem('currentUser', JSON.stringify(user.body));
                this.currentUserSubject.next(user.body);
                return user.body;
            }));
    }

    logout() {
        // remove user from local storage to log user out
        const currentUser = JSON.parse(localStorage.getItem('currentUser'));

        const bodyQuery = {
            token: currentUser.access_token
        };
        this.dataService.post('logout', bodyQuery).subscribe(data => {
            console.log('Logout successfully!');
        });
        localStorage.removeItem('currentUser');
        this.currentUserSubject.next(null);
        return true;
    }
}
